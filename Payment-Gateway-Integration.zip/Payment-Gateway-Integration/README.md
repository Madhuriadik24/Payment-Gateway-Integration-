# Payment-Gateway-Integration_TSFoundation
Payment Gateway Integration


A simple Responsive website where payment gateway is integrated. 💯💯

There will be a simple donate button on the homepage. On clicking the donate button,
the user will land on the payment page where the user can select the choice of a gateway 
than the amount to be paid and the payment type, e.g. credit card, Paypal, etc. 💯

Once the payment is done an invoice will be generated and an email will be sent to the user
for the payment received. The invoice will contain the amount. 🎱🎱

<!----------------------------------------------->

The website hosted at 000webhost 👍👍👍 

    https://donation-bhavjot.000webhostapp.com/
    
The Working Video is also available on Youtube 👍👍👍 
    
    https://youtu.be/vnyPOmZaQwM

<!----------------------------------------------->
<!----------------------------------------------->

# Tech Stacks 👍 :- 
  
  Front End :-
        
        Html
        CSS
        JS

<!----------------------------------------------->
<!----------------------------------------------->

# Gateway Used 👍 :- 

    RazorPay
    PayU
    
<!----------------------------------------------->
<!----------------------------------------------->

This Project was given by THE SPARKS FOUNDATION 

    https://www.thesparksfoundationsingapore.org/

Under the Graduate Rotational Internship Program (GRIP)

    https://www.thesparksfoundationsingapore.org/join-us/internship-positions/



 
